<?php
	class TimberPostSubclass extends TimberPost {

		public function foo(){
			return 'bar';
		}

	}